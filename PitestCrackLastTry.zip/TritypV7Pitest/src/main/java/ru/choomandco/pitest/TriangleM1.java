package ru.choomandco.pitest;

public class TriangleM1 {
	
	  private int i;
	  private int j;
	  private int k;
	  
	  public TriangleM1(){
		  	i =0;
		  	j=0;
		  	k=0;
	  }
	  
	  public TriangleM1(int ii, int jj, int kk){
	    i=ii;
	    j=jj;
	    k=kk;
	  }
	  
	  public int geti(){
	    return i;
	  }

	  public void seti(int ii){
	    i = ii;
	  }

	  public int getj(){
	    return j;
	  }

	  public void setj(int jj){
	    j = jj;
	  }

	  public int getk(){
	    return k;
	  }

	  public void setk(int kk){
	    k = kk;
	  }
	  
	  public String toString(){
	    return ("Tri(P1("+geti()+","+getj()+"), " + "P2("+getk()+"))");
	  }
	  
	  /*
	   * Programme classique du triangle 
	   * (from http://www.irisa.fr/lande/gotlieb/resources/Java_exp/trityp/mutants/TritypInteger.java)
	   * 
	   * return 1 si le triangle est quelconque (scalène)
	   * return 2 si le triangle est isocele
	   * return 3 si le triangle est equilateral
	   * return 4 si ce n est pas un triangle
	   */
	  public int trityp(){
	      int trityp ;
	      if ( (i == 0) || (j == 0) || (k == 0))
	        trityp = 4 ;
	      else
	        {
	          trityp = 0 ;
	          if ( i == j)
	            trityp = trityp + 1 ;
	          if ( i == k) 
	            trityp = trityp + 2 ;
	          if ( j == k )
	            trityp = trityp + 3 ;
	          if (trityp == 0)        
	            {
	              if ( (i+j <= k) || (j+k <= i) || (i+k <= j))
	                trityp = 4 ;
	              else
	            	trityp = 1 ; 
	            }
	          else
	            {
	              if (trityp > 3)
	                trityp = 3 ; 
	              else 
	                if ( (trityp == 1) && (i+j > k) )
	                  trityp = 2 ;
	                else
			    if ( (trityp == 3) && (i+k > j) ) // Mutant 1: trityp == 3 instead of trityp == 2
	                    trityp = 2 ;
	                  else
	                    if ( (trityp == 3) && (j+k > i))
	                      trityp  = 2 ;
	                    else
	                      trityp = 4 ;
	            }
	        }
	      return(trityp) ;
	    }
	  
		static public String conversionTrityp(int i){
			switch (i){
				case 1:
					return "scalen";
				case 2:
					return "isosceles";
				case 3: 
					return "equilateral";
				default:
					return "not a ";
			}
		}
		
		
		 public static void main(String[] args) {
			  // Lecture des arguments
			  int i = 0, j = 0, k = 0;
			  if (args.length > 2) {
			      try {
			          i = Integer.parseInt(args[0]);
			          j = Integer.parseInt(args[1]);
			          k = Integer.parseInt(args[2]);
			      } catch (NumberFormatException e) {
			          System.err.println("Argument must be an integer");
			          System.exit(1);
			      }
			  }
				// Déclaration of triangles
			    TriangleM1 t = new TriangleM1(i,j,k);
			    
			    int type = t.trityp();
			    System.out.println("number:  "+type);
			    System.out.println("t is a "+ TriangleM1.conversionTrityp(type)+" triangle");
		 }
}
