package ru.choomandco.pitest;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


public class TriangleM4Test {

    @Test
    public void testGettersAndSetters() {
        TriangleM4 triangle = new TriangleM4();
        triangle.seti(3);
        triangle.setj(4);
        triangle.setk(5);
        assertEquals(3, triangle.geti());
        assertEquals(4, triangle.getj());
        assertEquals(5, triangle.getk());
    }

    @Test
    public void testToString() {
        TriangleM4 triangle = new TriangleM4(3, 4, 5);
        assertEquals("Tri(P1(3,4), P2(5))", triangle.toString());
    }

    @Test
    public void testTriangleM4Type() {
        Map<TriangleM4, Integer> trHolder = new HashMap<>();
        for (int i = 0; i <= 15; i++) {
            for (int j = 0; j <= 15; j++) {
                for (int k = 0; k <= 15; k++) {
                    TriangleM4 tr = new TriangleM4(i, j, k);
                    int res = tr.trityp();
                    trHolder.put(tr, res);
                }
            }
        }

        for (Map.Entry<TriangleM4, Integer> entry : trHolder.entrySet()) {
            int await = entry.getValue();
            assertEquals(await, entry.getKey().trityp());
        }
    }

    @Test
    public void testConversionTrityp() {
        TriangleM4 tr = new TriangleM4();
        int input1 = 1;
        int input2 = 2;
        int input3 = 3;
        int input4 = 4;

        String result1 = tr.conversionTrityp(input1);
        String result2 = tr.conversionTrityp(input2);
        String result3 = tr.conversionTrityp(input3);
        String result4 = tr.conversionTrityp(input4);

        assertEquals("scalen", result1);
        assertEquals("isosceles", result2);
        assertEquals("equilateral", result3);
        assertEquals("not a ", result4);
    }

    @Test
    public void testConversionTritypScalene() {
        assertEquals("scalen", TriangleM4.conversionTrityp(1));
    }

    @Test
    public void testConversionTritypIsosceles() {
        assertEquals("isosceles", TriangleM4.conversionTrityp(2));
    }

    @Test
    public void testConversionTritypEquilateral() {
        assertEquals("equilateral", TriangleM4.conversionTrityp(3));
    }

    @Test
    public void testConversionTritypNotATriangleM4() {
        assertEquals("not a ", TriangleM4.conversionTrityp(0));
    }

    @Test
    public void testConversionTritypNegativeValue() {
        assertEquals("not a ", TriangleM4.conversionTrityp(-1));
    }

    @Test
    public void testEquilateralTriangleM4() {
        TriangleM4 triangle = new TriangleM4(5, 5, 5);
        assertEquals(3, triangle.trityp());
    }

    @Test
    public void testIsoscelesTriangleM4() {
        TriangleM4 triangle = new TriangleM4(5, 5, 8);
        assertEquals(2, triangle.trityp());
    }

    @Test
    public void testScaleneTriangleM4() {
        TriangleM4 triangle = new TriangleM4(3, 4, 5);
        assertEquals(1, triangle.trityp());
    }

    @Test
    public void testNotATriangleM4() {
        TriangleM4 triangle = new TriangleM4(0, 1, 2);
        assertEquals(4, triangle.trityp());
    }

    @Test
    public void testNegativeValues() {
        TriangleM4 triangle = new TriangleM4(-1, -2, -3);
        assertEquals(4, triangle.trityp());
    }

    @Test
    public void testMainWithValidInput() {
        String[] args = {"3", "4", "5"};
        TriangleM4.main(args);
    }

//    @Test
//    public void testMainWithInvalidInput() {
//        String[] args = {"a", "b", "c"};
//        assertThrows(NumberFormatException.class, () -> {
//            Triangle.main(args);
//        });
//    }

    @Test
    public void testMainWithInsufficientInput() {
        String[] args = {"3", "4"};
        TriangleM4.main(args);
    }
}
