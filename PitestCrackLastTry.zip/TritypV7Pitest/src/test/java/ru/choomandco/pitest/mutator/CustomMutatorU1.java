//package ru.choomandco.pitest.mutator;
//
//import org.pitest.mutationtest.engine.gregor.MethodInfo;
//import org.pitest.mutationtest.engine.gregor.MethodMutatorFactory;
//import org.pitest.mutationtest.engine.gregor.MutationContext;
//import org.pitest.reloc.asm.MethodVisitor;
//import org.pitest.reloc.asm.Opcodes;
//
//public enum CustomMutatorU1 implements MethodMutatorFactory {
//
//    CUSTOM_MUTATOR_U1;
//
//    @Override
//    public MethodVisitor create(final MutationContext context, final MethodInfo methodInfo, final MethodVisitor methodVisitor) {
//        return new CustomMethodVisitor(this, context, methodVisitor);
//    }
//
//    @Override
//    public String getGloballyUniqueId() {
//        return "CUSTOM_MUTATOR_U1";
//    }
//
//    @Override
//    public String getName() {
//        return "CUSTOM_MUTATOR_U1";
//    }
//
//    private static class CustomMethodVisitor extends MethodVisitor {
//        private final MutationContext context;
//        private final MethodMutatorFactory factory;
//
//        CustomMethodVisitor(final MethodMutatorFactory factory, final MutationContext context, final MethodVisitor delegateMethodVisitor) {
//            super(Opcodes.ASM7, delegateMethodVisitor);
//            this.context = context;
//            this.factory = factory;
//        }
//
//        @Override
//        public void visitJumpInsn(int opcode, org.pitest.reloc.asm.Label label) {
//            if (opcode == Opcodes.IFEQ) {
//                final org.pitest.reloc.asm.Label newLabel = new org.pitest.reloc.asm.Label();
//                super.visitJumpInsn(Opcodes.IFNE, newLabel);
//                super.visitLabel(newLabel);
//                context.registerMutation(factory, "Replaced IFEQ with IFNE");
//            } else {
//                super.visitJumpInsn(opcode, label);
//            }
//        }
//    }
//}
